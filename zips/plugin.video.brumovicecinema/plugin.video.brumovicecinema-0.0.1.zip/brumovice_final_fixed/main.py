import xbmcplugin
import xbmcgui
import xbmcaddon
import sys
import urllib.parse

addon = xbmcaddon.Addon()
handle = int(sys.argv[1])
base_url = sys.argv[0]

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def main_menu():
    items = [
        ("Vyhledávání", "search"),
        ("Filmy", "movies"),
        ("Seriály", "series"),
        ("TV Program", "tvguide"),
        ("Trakt.tv", "trakt"),
        ("TMDB", "tmdb"),
        ("ČSFD", "csfd"),
        ("Nastavení", "settings"),
    ]
    for name, action in items:
        li = xbmcgui.ListItem(label=name)
        url = build_url({'action': action})
        xbmcplugin.addDirectoryItem(handle, url, li, True)
    xbmcplugin.endOfDirectory(handle)

if __name__ == '__main__':
    main_menu()
