import xbmcplugin
import xbmcgui
import sys
xbmcplugin.endOfDirectory(int(sys.argv[1]))